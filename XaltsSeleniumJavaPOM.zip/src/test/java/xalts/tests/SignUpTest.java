
package xalts.tests;

import xalts.BaseTest;
import xalts.pages.SignUpPage;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class SignUpTest extends BaseTest {

    @Test
    public void testValidSignUp() {
        SignUpPage signUpPage = new SignUpPage(driver);
        signUpPage.openSignUp();
        signUpPage.signUp("testuser@example.com", "TestPassword123");
        assertTrue(driver.getCurrentUrl().toLowerCase().contains("dashboard"));
    }
}
