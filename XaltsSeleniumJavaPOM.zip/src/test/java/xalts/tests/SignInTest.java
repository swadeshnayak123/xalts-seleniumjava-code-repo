
package xalts.tests;

import xalts.BaseTest;
import xalts.pages.LoginPage;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class SignInTest extends BaseTest {

    @Test
    public void testValidSignIn() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.openSignIn();
        loginPage.signIn("testuser@example.com", "TestPassword123");
        assertTrue(driver.getCurrentUrl().toLowerCase().contains("dashboard"));
    }
}
