
package xalts.tests;

import xalts.BaseTest;
import xalts.pages.LoginPage;
import xalts.pages.NodeWalletPage;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class NodeWalletTest extends BaseTest {

    @Test
    public void testSubmitNodeAndWalletRequest() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.openSignIn();
        loginPage.signIn("testuser@example.com", "TestPassword123");

        NodeWalletPage nodeWalletPage = new NodeWalletPage(driver);
        nodeWalletPage.addNode("NodeID-101", "192.168.1.10");
        nodeWalletPage.clickNextAfterNodes();
        nodeWalletPage.addWallet("0x88fa61d2faA13aad8Fbd5B030372B4A159BbbDFb", "Read");
        nodeWalletPage.clickNextAfterWallets();
        nodeWalletPage.submitRequest();

        assertTrue(driver.getPageSource().contains("submitted") || 
                   driver.getCurrentUrl().toLowerCase().contains("success"));
    }
}
