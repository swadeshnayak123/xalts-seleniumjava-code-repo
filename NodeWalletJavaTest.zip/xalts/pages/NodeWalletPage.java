
package xalts.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class NodeWalletPage {
    WebDriver driver;

    public NodeWalletPage(WebDriver driver) {
        this.driver = driver;
    }

    public void addNode(String nodeId, String ip) {
        driver.findElement(By.name("nodeId")).sendKeys(nodeId);
        driver.findElement(By.name("publicIp")).sendKeys(ip);
        driver.findElement(By.xpath("//button[contains(text(), 'ADD NODE')]")).click();
    }

    public void clickNextAfterNodes() {
        driver.findElement(By.xpath("//button[contains(text(), 'NEXT')]")).click();
    }

    public void addWallet(String address, String permissionType) {
        driver.findElement(By.name("walletAddress")).sendKeys(address);
        driver.findElement(By.name("permissionType")).sendKeys(permissionType);
        driver.findElement(By.xpath("//button[contains(text(), 'ADD WALLET')]")).click();
    }

    public void clickNextAfterWallets() {
        driver.findElement(By.xpath("//button[contains(text(), 'NEXT')]")).click();
    }

    public void submitRequest() {
        driver.findElement(By.xpath("//button[contains(text(), 'SUBMIT')]")).click();
    }
}
